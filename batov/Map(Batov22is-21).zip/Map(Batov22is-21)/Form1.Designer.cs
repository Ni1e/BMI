﻿namespace Map_Batov22is_21_
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Finish = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button_7 = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Back);
            this.panel1.Location = new System.Drawing.Point(-2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(690, 43);
            this.panel1.TabIndex = 0;
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(3, 8);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(80, 30);
            this.Back.TabIndex = 0;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(104, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(493, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Interactive map for Marathon Skiills";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(557, 46);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(131, 192);
            this.panel2.TabIndex = 2;
            // 
            // Finish
            // 
            this.Finish.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Finish.Image = global::Map_Batov22is_21_.Properties.Resources.finish;
            this.Finish.Location = new System.Drawing.Point(198, 46);
            this.Finish.Name = "Finish";
            this.Finish.Size = new System.Drawing.Size(36, 97);
            this.Finish.TabIndex = 11;
            this.Finish.UseVisualStyleBackColor = false;
            // 
            // button_1
            // 
            this.button_1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_1.Image = global::Map_Batov22is_21_.Properties.Resources._1;
            this.button_1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_1.Location = new System.Drawing.Point(307, 51);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(66, 61);
            this.button_1.TabIndex = 10;
            this.button_1.UseVisualStyleBackColor = false;
            // 
            // button_2
            // 
            this.button_2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button_2.Image = global::Map_Batov22is_21_.Properties.Resources._2;
            this.button_2.Location = new System.Drawing.Point(450, 150);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(62, 61);
            this.button_2.TabIndex = 9;
            this.button_2.UseVisualStyleBackColor = false;
            // 
            // button_3
            // 
            this.button_3.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_3.Image = global::Map_Batov22is_21_.Properties.Resources._3;
            this.button_3.Location = new System.Drawing.Point(450, 251);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(61, 67);
            this.button_3.TabIndex = 8;
            this.button_3.UseVisualStyleBackColor = false;
            // 
            // button_4
            // 
            this.button_4.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_4.Image = global::Map_Batov22is_21_.Properties.Resources._4;
            this.button_4.Location = new System.Drawing.Point(619, 324);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(69, 64);
            this.button_4.TabIndex = 7;
            this.button_4.UseVisualStyleBackColor = false;
            // 
            // button_5
            // 
            this.button_5.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_5.Image = global::Map_Batov22is_21_.Properties.Resources._5;
            this.button_5.Location = new System.Drawing.Point(368, 389);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(61, 60);
            this.button_5.TabIndex = 6;
            this.button_5.UseVisualStyleBackColor = false;
            // 
            // button_6
            // 
            this.button_6.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_6.Image = global::Map_Batov22is_21_.Properties.Resources._6;
            this.button_6.Location = new System.Drawing.Point(178, 376);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(71, 62);
            this.button_6.TabIndex = 5;
            this.button_6.UseVisualStyleBackColor = false;
            // 
            // button_7
            // 
            this.button_7.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_7.Image = global::Map_Batov22is_21_.Properties.Resources._7;
            this.button_7.Location = new System.Drawing.Point(76, 285);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(71, 62);
            this.button_7.TabIndex = 4;
            this.button_7.UseVisualStyleBackColor = false;
            // 
            // button_8
            // 
            this.button_8.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_8.Image = global::Map_Batov22is_21_.Properties.Resources._8;
            this.button_8.Location = new System.Drawing.Point(39, 154);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(68, 57);
            this.button_8.TabIndex = 3;
            this.button_8.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Map_Batov22is_21_.Properties.Resources.map;
            this.pictureBox1.Location = new System.Drawing.Point(-2, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(699, 403);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 450);
            this.Controls.Add(this.Finish);
            this.Controls.Add(this.button_1);
            this.Controls.Add(this.button_2);
            this.Controls.Add(this.button_3);
            this.Controls.Add(this.button_4);
            this.Controls.Add(this.button_5);
            this.Controls.Add(this.button_6);
            this.Controls.Add(this.button_7);
            this.Controls.Add(this.button_8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Marathon";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Back;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_8;
        private System.Windows.Forms.Button button_7;
        private System.Windows.Forms.Button button_6;
        private System.Windows.Forms.Button button_5;
        private System.Windows.Forms.Button button_4;
        private System.Windows.Forms.Button button_3;
        private System.Windows.Forms.Button button_2;
        private System.Windows.Forms.Button button_1;
        private System.Windows.Forms.Button Finish;
    }
}

